#include "EPXPlatform_Runtime.h"
#include "EPXPlatform_Crypto.h"



void EPXPlatform_Crypto_Initialize()
{
}



uint8_t *EPXPlatform_Crypto_Encrypt(uint8_t * pAESKey, void *p_data, size_t len)
{
	return NULL;
}



uint8_t *EPXPlatform_Crypto_Decrypt(uint8_t * pAESKey, void *p_data, size_t len)
{
	return NULL;
}




void EPXPlatform_Crypto_GenerateNONCE(uint8_t * p_buf)
{

}

