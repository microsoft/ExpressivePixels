Welcome to the Microsoft Expressive Pixels project!! 

Please be sure to visit the Wiki at https://github.com/microsoft/ExpressivePixels/wiki
to learn more about how to integrate Expressive Pixels capabilities in your own creations.