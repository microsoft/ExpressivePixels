#include <Arduino.h>

#define EPX_OPTIMIZEFORDEBUGGING_ON 
#define DEBUGLOGLN

#define TMALLOC(size) malloc(size)
#define TFREE(ptr) free((uint8_t *) ptr)
	