#include <Arduino.h>

#define EPX_OPTIMIZEFORDEBUGGING_ON 
#define DEBUGLOGLN